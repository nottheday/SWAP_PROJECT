-- XSS Lab Database Setup
-- Run this in phpMyAdmin or MySQL command line

CREATE DATABASE IF NOT EXISTS xss_lab;
USE xss_lab;

-- Comments table for persistent XSS demonstration
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert some sample safe comments
INSERT INTO comments (username, comment) VALUES
('Alice', 'This is a great website!'),
('Bob', 'I learned a lot from this tutorial.'),
('Charlie', 'Thanks for sharing this information.');

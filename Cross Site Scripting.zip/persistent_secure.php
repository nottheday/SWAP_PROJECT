<?php
require_once 'utility.php';
require_once 'config.php';

/**
 * Sanitization Functions - Different methods to prevent XSS
 */

// Method 1: HTML Special Characters Encoding
function sanitize_htmlspecialchars($input) {
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

// Method 2: Strip HTML Tags
function sanitize_strip_tags($input) {
    return strip_tags($input);
}

// Method 3: Whitelist - Only allow alphanumeric, spaces, and basic punctuation
function sanitize_whitelist($input) {
    // Only allow: letters, numbers, spaces, and basic punctuation (. , ! ? - ')
    return preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\']/u', '', $input);
}

// Get selected method (default to htmlspecialchars)
$method = isset($_GET['method']) ? $_GET['method'] : 'htmlspecialchars';
$validMethods = ['htmlspecialchars', 'strip_tags', 'whitelist'];
if (!in_array($method, $validMethods)) {
    $method = 'htmlspecialchars';
}

// Apply the selected sanitization method
function sanitize($input, $method) {
    switch ($method) {
        case 'strip_tags':
            return sanitize_strip_tags($input);
        case 'whitelist':
            return sanitize_whitelist($input);
        case 'htmlspecialchars':
        default:
            return sanitize_htmlspecialchars($input);
    }
}

$conn = getDBConnection();
$message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && isset($_POST['comment'])) {
        $username = trim($_POST['username']);
        $comment = trim($_POST['comment']);

        $stmt = $conn->prepare("INSERT INTO comments (username, comment) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $comment);

        if ($stmt->execute()) {
            $message = '<div class="info-box">Comment posted successfully!</div>';
        } else {
            $message = '<div class="warning-box">Error posting comment.</div>';
        }
        $stmt->close();
    }
}

// Handle clear comments
if (isset($_GET['clear']) && $_GET['clear'] === '1') {
    $conn->query("DELETE FROM comments");
    $conn->query("ALTER TABLE comments AUTO_INCREMENT = 1");
    header("Location: persistent_secure.php?method=" . $method);
    exit;
}

// Fetch all comments
$result = $conn->query("SELECT * FROM comments ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persistent XSS - Secure</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php dev_header(__FILE__); ?>
    <div class="container">
        <h1>Persistent XSS Lab</h1>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="persistent_vulnerable.php">View Vulnerable Version</a>
        </div>

        <div class="card secure">
            <span class="badge badge-success">SECURE</span>
            <h2>Comment Section (Fixed)</h2>

            <div class="info-box">
                <strong>This page demonstrates multiple XSS prevention methods on OUTPUT.</strong>
            </div>

            <!-- Method Selector -->
            <div class="info-box" style="background: rgba(255, 165, 2, 0.2); border-color: #ffa502;">
                <strong>Select Sanitization Method:</strong>
                <div style="display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap;">
                    <a href="?method=htmlspecialchars">
                        <button type="button" style="<?php echo $method === 'htmlspecialchars' ? 'background: #2ed573;' : ''; ?>">
                            htmlspecialchars()
                        </button>
                    </a>
                    <a href="?method=strip_tags">
                        <button type="button" style="<?php echo $method === 'strip_tags' ? 'background: #2ed573;' : ''; ?>">
                            strip_tags()
                        </button>
                    </a>
                    <a href="?method=whitelist">
                        <button type="button" style="<?php echo $method === 'whitelist' ? 'background: #2ed573;' : ''; ?>">
                            Whitelist
                        </button>
                    </a>
                </div>
                <p style="margin-top: 10px; color: #ffa502;">
                    Currently using: <code><?php echo $method; ?></code>
                </p>
            </div>

            <?php echo $message; ?>

            <form method="POST" action="?method=<?php echo $method; ?>">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your name..."
                       maxlength="100" required>

                <label for="comment">Comment:</label>
                <textarea id="comment" name="comment" rows="4" placeholder="Write your comment..." required></textarea>

                <button type="submit">Post Comment</button>
            </form>

            <a href="?clear=1&method=<?php echo $method; ?>" onclick="return confirm('Are you sure you want to delete all comments?');">
                <button type="button" class="clear-btn">Clear All Comments</button>
            </a>

            <h3 style="margin-top: 30px; color: #00d4ff;">Comments</h3>

            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                <div class="comment-box">
                    <div class="username">
                        <strong>Raw (in DB):</strong> <code style="color: #ff6b6b;"><?php echo htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8'); ?></code><br>
                        <strong>Sanitized:</strong> <?php echo sanitize($row['username'], $method); ?>
                    </div>
                    <div class="time"><?php echo htmlspecialchars($row['created_at'], ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="content">
                        <strong>Raw (in DB):</strong> <code style="color: #ff6b6b;"><?php echo htmlspecialchars($row['comment'], ENT_QUOTES, 'UTF-8'); ?></code><br>
                        <strong>Sanitized:</strong> <?php echo sanitize($row['comment'], $method); ?>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #a4b0be; margin-top: 20px;">No comments yet. Be the first to comment!</p>
            <?php endif; ?>

            <div class="info-box" style="margin-top: 30px;">
                <strong>Try posting malicious comments:</strong><br>
                Then switch between methods to see how each handles the stored XSS payload:
                <pre><code>&lt;script&gt;alert('Stored XSS!')&lt;/script&gt;</code></pre>
                <pre><code>&lt;img src=x onerror="alert('XSS')"&gt;</code></pre>
            </div>

            <!-- Method Explanations -->
            <div class="info-box" style="<?php echo $method === 'htmlspecialchars' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 1: htmlspecialchars()</strong>
                <pre><code>echo htmlspecialchars($row['comment'], ENT_QUOTES, 'UTF-8');</code></pre>
                <p style="margin-top: 10px;"><strong>Result:</strong> Script tags become visible text: <code>&amp;lt;script&amp;gt;</code></p>
                <p style="color: #2ed573;"><strong>Best for:</strong> Displaying user content where you want to show exactly what they typed</p>
            </div>

            <div class="info-box" style="<?php echo $method === 'strip_tags' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 2: strip_tags()</strong>
                <pre><code>echo strip_tags($row['comment']);</code></pre>
                <p style="margin-top: 10px;"><strong>Result:</strong> All HTML tags are removed completely</p>
                <p style="color: #2ed573;"><strong>Best for:</strong> Plain text fields where no HTML is ever needed</p>
                <p style="color: #ff6b6b;"><strong>Caution:</strong> Can be bypassed with malformed tags like <code>&lt;scr&lt;script&gt;ipt&gt;</code></p>
            </div>

            <div class="info-box" style="<?php echo $method === 'whitelist' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 3: Whitelist (Regex)</strong>
                <pre><code>preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\']/u', '', $input);</code></pre>
                <p style="margin-top: 10px;"><strong>Result:</strong> Only allowed characters remain (letters, numbers, spaces, basic punctuation)</p>
                <p style="color: #2ed573;"><strong>Best for:</strong> Strict input fields like usernames, search terms</p>
                <p style="color: #ff6b6b;"><strong>Caution:</strong> Removes special characters users might legitimately need</p>
            </div>

            <div class="warning-box">
                <strong>Key Insight:</strong> Notice that the data is stored RAW in the database.
                The sanitization happens on <strong>OUTPUT</strong>, not input. This is the recommended approach
                because it allows you to change sanitization methods later without losing original data.
            </div>

            <div class="info-box">
                <strong>Defense in Depth - Combine Methods:</strong>
                <ul style="margin-top: 10px; margin-left: 20px;">
                    <li><strong>Output encoding</strong> (htmlspecialchars) - Primary defense</li>
                    <li><strong>Input validation</strong> (whitelist) - Secondary defense</li>
                    <li><strong>Content Security Policy</strong> - Prevent inline script execution</li>
                    <li><strong>HTTPOnly cookies</strong> - Protect session from theft</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>

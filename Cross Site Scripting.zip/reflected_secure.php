<?php
require_once 'utility.php';

/**
 * Sanitization Functions - Different methods to prevent XSS
 */

// Method 1: HTML Special Characters Encoding
function sanitize_htmlspecialchars($input) {
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

// Method 2: Strip HTML Tags
function sanitize_strip_tags($input) {
    return strip_tags($input);
}

// Method 3: Whitelist - Only allow alphanumeric, spaces, and basic punctuation
function sanitize_whitelist($input) {
    // Only allow: letters, numbers, spaces, and basic punctuation (. , ! ? - ')
    return preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\']/u', '', $input);
}

// Get selected method (default to htmlspecialchars)
$method = isset($_GET['method']) ? $_GET['method'] : 'htmlspecialchars';
$validMethods = ['htmlspecialchars', 'strip_tags', 'whitelist'];
if (!in_array($method, $validMethods)) {
    $method = 'htmlspecialchars';
}

// Apply the selected sanitization method
function sanitize($input, $method) {
    switch ($method) {
        case 'strip_tags':
            return sanitize_strip_tags($input);
        case 'whitelist':
            return sanitize_whitelist($input);
        case 'htmlspecialchars':
        default:
            return sanitize_htmlspecialchars($input);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reflected XSS - Secure</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php dev_header(__FILE__); ?>
    <div class="container">
        <h1>Reflected XSS Lab</h1>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="reflected_vulnerable.php">View Vulnerable Version</a>
        </div>

        <div class="card secure">
            <span class="badge badge-success">SECURE</span>
            <h2>Search Page (Fixed)</h2>

            <div class="info-box">
                <strong>This page demonstrates multiple XSS prevention methods.</strong>
            </div>

            <!-- Method Selector -->
            <div class="info-box" style="background: rgba(255, 165, 2, 0.2); border-color: #ffa502;">
                <strong>Select Sanitization Method:</strong>
                <div style="display: flex; gap: 10px; margin-top: 15px; flex-wrap: wrap;">
                    <a href="?method=htmlspecialchars<?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">
                        <button type="button" style="<?php echo $method === 'htmlspecialchars' ? 'background: #2ed573;' : ''; ?>">
                            htmlspecialchars()
                        </button>
                    </a>
                    <a href="?method=strip_tags<?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">
                        <button type="button" style="<?php echo $method === 'strip_tags' ? 'background: #2ed573;' : ''; ?>">
                            strip_tags()
                        </button>
                    </a>
                    <a href="?method=whitelist<?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">
                        <button type="button" style="<?php echo $method === 'whitelist' ? 'background: #2ed573;' : ''; ?>">
                            Whitelist
                        </button>
                    </a>
                </div>
                <p style="margin-top: 10px; color: #ffa502;">
                    Currently using: <code><?php echo $method; ?></code>
                </p>
            </div>

            <form method="GET" action="">
                <input type="hidden" name="method" value="<?php echo $method; ?>">
                <label for="search">Search for something:</label>
                <input type="text" id="search" name="search" placeholder="Enter your search query...">
                <button type="submit">Search</button>
            </form>

            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
            <div class="result">
                <h3>Search Results</h3>
                <p><strong>Original input:</strong> <code><?php echo htmlspecialchars($_GET['search'], ENT_QUOTES, 'UTF-8'); ?></code></p>
                <p><strong>Sanitized output:</strong> <?php echo sanitize($_GET['search'], $method); ?></p>
                <p><em>No results found for your query.</em></p>
            </div>
            <?php endif; ?>

            <!-- Method 1: htmlspecialchars -->
            <div class="info-box" style="<?php echo $method === 'htmlspecialchars' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 1: htmlspecialchars()</strong>
                <pre><code>function sanitize_htmlspecialchars($input) {
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}</code></pre>
                <p style="margin-top: 10px;"><strong>How it works:</strong> Converts special HTML characters to entities:</p>
                <ul style="margin: 10px 0 0 20px;">
                    <li><code>&lt;</code> becomes <code>&amp;lt;</code></li>
                    <li><code>&gt;</code> becomes <code>&amp;gt;</code></li>
                    <li><code>"</code> becomes <code>&amp;quot;</code></li>
                    <li><code>'</code> becomes <code>&amp;#039;</code></li>
                </ul>
                <p style="margin-top: 10px; color: #2ed573;"><strong>Pros:</strong> Preserves all text, just encodes it safely</p>
                <p style="color: #ff6b6b;"><strong>Cons:</strong> Tags appear as visible text</p>
            </div>

            <!-- Method 2: strip_tags -->
            <div class="info-box" style="<?php echo $method === 'strip_tags' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 2: strip_tags()</strong>
                <pre><code>function sanitize_strip_tags($input) {
    return strip_tags($input);
}</code></pre>
                <p style="margin-top: 10px;"><strong>How it works:</strong> Completely removes all HTML and PHP tags from the string.</p>
                <p style="margin-top: 10px;"><strong>Example:</strong></p>
                <ul style="margin: 10px 0 0 20px;">
                    <li><code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code> becomes <code>alert('XSS')</code></li>
                    <li><code>&lt;b&gt;Hello&lt;/b&gt;</code> becomes <code>Hello</code></li>
                </ul>
                <p style="margin-top: 10px; color: #2ed573;"><strong>Pros:</strong> Simple, removes all tags entirely</p>
                <p style="color: #ff6b6b;"><strong>Cons:</strong> Loses formatting, can be bypassed with malformed tags in some cases</p>
            </div>

            <!-- Method 3: Whitelist -->
            <div class="info-box" style="<?php echo $method === 'whitelist' ? 'border-color: #2ed573; border-width: 2px;' : ''; ?>">
                <strong>Method 3: Whitelist (Regex)</strong>
                <pre><code>function sanitize_whitelist($input) {
    // Only allow: letters, numbers, spaces, and basic punctuation
    return preg_replace('/[^a-zA-Z0-9\s\.\,\!\?\-\']/u', '', $input);
}</code></pre>
                <p style="margin-top: 10px;"><strong>How it works:</strong> Only allows specific characters, removes everything else.</p>
                <p style="margin-top: 10px;"><strong>Allowed characters:</strong> <code>a-z A-Z 0-9 space . , ! ? - '</code></p>
                <p style="margin-top: 10px;"><strong>Example:</strong></p>
                <ul style="margin: 10px 0 0 20px;">
                    <li><code>&lt;script&gt;</code> becomes <code>script</code> (removes &lt; and &gt;)</li>
                </ul>
                <p style="margin-top: 10px; color: #2ed573;"><strong>Pros:</strong> Very strict, only allows known-safe characters</p>
                <p style="color: #ff6b6b;"><strong>Cons:</strong> May remove legitimate characters (accents, unicode, etc.)</p>
            </div>

            <div class="warning-box">
                <strong>Recommendation:</strong> Use <code>htmlspecialchars()</code> as the primary defense.
                It's the most reliable for HTML context. Combine with Content Security Policy headers for defense in depth.
            </div>
        </div>
    </div>
</body>
</html>

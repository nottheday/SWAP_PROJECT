<?php
require_once 'utility.php';
require_once 'config.php';

$conn = getDBConnection();
$message = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && isset($_POST['comment'])) {
        $username = $_POST['username'];
        $comment = $_POST['comment'];

        $stmt = $conn->prepare("INSERT INTO comments (username, comment) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $comment);

        if ($stmt->execute()) {
            $message = '<div class="info-box">Comment posted successfully!</div>';
        } else {
            $message = '<div class="warning-box">Error posting comment.</div>';
        }
        $stmt->close();
    }
}

// Handle clear comments
if (isset($_GET['clear']) && $_GET['clear'] === '1') {
    $conn->query("DELETE FROM comments");
    $conn->query("ALTER TABLE comments AUTO_INCREMENT = 1");
    header("Location: persistent_vulnerable.php");
    exit;
}

// Fetch all comments
$result = $conn->query("SELECT * FROM comments ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persistent XSS - Vulnerable</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php dev_header(__FILE__); ?>
    <div class="container">
        <h1>Persistent XSS Lab</h1>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="persistent_secure.php">View Secure Version</a>
        </div>

        <div class="card vulnerable">
            <span class="badge badge-danger">VULNERABLE</span>
            <h2>Comment Section</h2>

            <div class="warning-box">
                <strong>Warning:</strong> This page is intentionally vulnerable to Persistent (Stored) XSS attacks for educational purposes only.
            </div>

            <?php echo $message; ?>

            <form method="POST" action="">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your name..." required>

                <label for="comment">Comment:</label>
                <textarea id="comment" name="comment" rows="4" placeholder="Write your comment..." required></textarea>

                <button type="submit">Post Comment</button>
            </form>

            <a href="?clear=1" onclick="return confirm('Are you sure you want to delete all comments?');">
                <button type="button" class="clear-btn">Clear All Comments</button>
            </a>

            <h3 style="margin-top: 30px; color: #00d4ff;">Comments</h3>

            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                <div class="comment-box">
                    <div class="username"><?php echo $row['username']; ?></div>
                    <!--
                        VULNERABILITY: Username is displayed without sanitization.
                        Malicious scripts stored in the database will execute for ALL users.
                    -->
                    <div class="time"><?php echo $row['created_at']; ?></div>
                    <div class="content"><?php echo $row['comment']; ?></div>
                    <!--
                        VULNERABILITY: Comment is displayed without sanitization.
                        This is PERSISTENT XSS - the malicious code is stored in the database
                        and executed every time anyone views this page.
                    -->
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="color: #a4b0be; margin-top: 20px;">No comments yet. Be the first to comment!</p>
            <?php endif; ?>

            <div class="info-box" style="margin-top: 30px;">
                <strong>How to exploit:</strong><br>
                Try posting a comment with one of these payloads:
                <pre><code>&lt;script&gt;alert('Stored XSS!')&lt;/script&gt;</code></pre>
                <pre><code>&lt;img src=x onerror="alert('XSS from ' + document.domain)"&gt;</code></pre>
                <pre><code>&lt;body onload="alert('XSS')"&gt;</code></pre>

                <br><strong>Cookie Stealing Example:</strong>
                <pre><code>&lt;script&gt;alert(document.cookie)&lt;/script&gt;</code></pre>
            </div>

            <div class="info-box">
                <strong>Why is Persistent XSS more dangerous?</strong>
                <ul style="margin-top: 10px; margin-left: 20px;">
                    <li>The malicious script is stored in the database</li>
                    <li>Every user who views this page will be affected</li>
                    <li>No need to trick users into clicking a malicious link</li>
                    <li>Can affect many users simultaneously</li>
                    <li>Can steal session cookies, credentials, or perform actions as the victim</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>

<?php
/**
 * Database Configuration for XSS Lab
 *
 * Make sure to:
 * 1. Start XAMPP (Apache and MySQL)
 * 2. Import database.sql in phpMyAdmin
 */

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Default XAMPP has no password
define('DB_NAME', 'xss_lab');

function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error .
            "<br><br><strong>Make sure to:</strong>" .
            "<ol>" .
            "<li>Start MySQL in XAMPP Control Panel</li>" .
            "<li>Import database.sql using phpMyAdmin</li>" .
            "</ol>");
    }

    $conn->set_charset("utf8mb4");
    return $conn;
}
?>

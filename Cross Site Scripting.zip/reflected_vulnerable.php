<?php require_once 'utility.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reflected XSS - Vulnerable</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php dev_header(__FILE__); ?>
    <div class="container">
        <h1>Reflected XSS Lab</h1>

        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="reflected_secure.php">View Secure Version</a>
        </div>

        <div class="card vulnerable">
            <span class="badge badge-danger">VULNERABLE</span>
            <h2>Search Page</h2>

            <div class="warning-box">
                <strong>Warning:</strong> This page is intentionally vulnerable to Reflected XSS attacks for educational purposes only.
            </div>

            <form method="GET" action="">
                <label for="search">Search for something:</label>
                <input type="text" id="search" name="search" placeholder="Enter your search query...">
                <button type="submit">Search</button>
            </form>

            <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
            <div class="result">
                <h3>Search Results</h3>
                <p>You searched for: <?php echo $_GET['search']; ?></p>
                <!--
                    VULNERABILITY: The user input is directly echoed without any sanitization.
                    An attacker can inject malicious JavaScript code.

                    Try this payload: <script>alert('XSS')</script>
                    Or this: <img src=x onerror="alert('XSS')">
                -->
                <p><em>No results found for your query.</em></p>
            </div>
            <?php endif; ?>

            <div class="info-box">
                <strong>How to exploit:</strong><br>
                Try entering one of these payloads in the search box:
                <pre><code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code></pre>
                <pre><code>&lt;img src=x onerror="alert('XSS')"&gt;</code></pre>
                <pre><code>&lt;svg onload="alert('XSS')"&gt;</code></pre>
            </div>

            <div class="info-box">
                <strong>Why is this vulnerable?</strong><br>
                The PHP code directly outputs user input without any encoding:
                <pre><code>&lt;?php echo $_GET['search']; ?&gt;</code></pre>
                This allows attackers to inject HTML and JavaScript that will be executed in the victim's browser.
            </div>
        </div>
    </div>
</body>
</html>

<?php require_once 'utility.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XSS Security Lab</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php dev_header(__FILE__); ?>
    <div class="container">
        <h1>XSS Security Lab</h1>

        <div class="card" style="text-align: center; margin-bottom: 40px;">
            <h2 style="border: none; color: #00d4ff;">Welcome to the XSS Learning Lab</h2>
            <p style="color: #a4b0be; font-size: 18px; margin-top: 15px;">
                Learn about Cross-Site Scripting (XSS) vulnerabilities in a safe environment.
            </p>

            <div class="warning-box" style="text-align: left;">
                <strong>Important Setup Instructions:</strong>
                <ol style="margin-top: 10px; margin-left: 20px; line-height: 2;">
                    <li>Start <strong>Apache</strong> and <strong>MySQL</strong> in XAMPP Control Panel</li>
                    <li>Open <strong>phpMyAdmin</strong> (http://localhost/phpmyadmin)</li>
                    <li>Import <code>database.sql</code> from this folder</li>
                    <li>You're ready to start the labs!</li>
                </ol>
            </div>
        </div>

        <!-- Reflected XSS Lab -->
        <div class="card lab-card">
            <h3>Lab 1: Reflected XSS</h3>
            <p>
                Reflected XSS occurs when user input is immediately returned by the server without proper sanitization.
                The malicious script is part of the request (usually in the URL) and "reflected" back to the user.
            </p>

            <div class="info-box" style="text-align: left;">
                <strong>Attack Vector:</strong> Malicious link sent to victim<br>
                <strong>Persistence:</strong> Not stored - requires victim to click link<br>
                <strong>Example:</strong> <code>search.php?q=&lt;script&gt;alert('XSS')&lt;/script&gt;</code>
            </div>

            <div class="btn-group">
                <a href="reflected_vulnerable.php">
                    <button class="btn-vulnerable">Vulnerable Version</button>
                </a>
                <a href="reflected_secure.php">
                    <button class="btn-secure">Secure Version</button>
                </a>
            </div>
        </div>

        <!-- Persistent XSS Lab -->
        <div class="card lab-card">
            <h3>Lab 2: Persistent (Stored) XSS</h3>
            <p>
                Persistent XSS occurs when malicious input is stored in the database and displayed to other users.
                This is more dangerous because it affects all users who view the infected content.
            </p>

            <div class="info-box" style="text-align: left;">
                <strong>Attack Vector:</strong> Malicious content stored in database<br>
                <strong>Persistence:</strong> Stored permanently until removed<br>
                <strong>Example:</strong> Malicious comment affects all visitors
            </div>

            <div class="btn-group">
                <a href="persistent_vulnerable.php">
                    <button class="btn-vulnerable">Vulnerable Version</button>
                </a>
                <a href="persistent_secure.php">
                    <button class="btn-secure">Secure Version</button>
                </a>
            </div>
        </div>

        <!-- Quick Reference -->
        <div class="card">
            <h2>Quick Reference: XSS Prevention</h2>

            <div class="info-box">
                <strong>The Golden Rule:</strong><br>
                Never trust user input. Always encode/escape output based on context.
            </div>

            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">PHP Functions for Prevention</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.2);">
                    <td style="padding: 10px; color: #ffa502;"><code>htmlspecialchars()</code></td>
                    <td style="padding: 10px;">Converts special chars to HTML entities (recommended)</td>
                </tr>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.2);">
                    <td style="padding: 10px; color: #ffa502;"><code>htmlentities()</code></td>
                    <td style="padding: 10px;">Converts all applicable chars to HTML entities</td>
                </tr>
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.2);">
                    <td style="padding: 10px; color: #ffa502;"><code>strip_tags()</code></td>
                    <td style="padding: 10px;">Removes HTML tags (use with caution)</td>
                </tr>
                <tr>
                    <td style="padding: 10px; color: #ffa502;"><code>filter_var()</code></td>
                    <td style="padding: 10px;">Filter/validate input with various filters</td>
                </tr>
            </table>

            <h3 style="color: #00d4ff; margin: 20px 0 10px 0;">Common XSS Payloads for Testing</h3>
            <pre><code>&lt;script&gt;alert('XSS')&lt;/script&gt;
&lt;img src=x onerror="alert('XSS')"&gt;
&lt;svg onload="alert('XSS')"&gt;
&lt;body onload="alert('XSS')"&gt;
&lt;iframe src="javascript:alert('XSS')"&gt;
&lt;a href="javascript:alert('XSS')"&gt;Click me&lt;/a&gt;</code></pre>
        </div>

        <!-- Footer -->
        <div style="text-align: center; color: #747d8c; margin-top: 40px; padding: 20px;">
            <p>XSS Security Lab - For Educational Purposes Only</p>
            <p style="font-size: 12px; margin-top: 10px;">
                Never use these techniques on systems without explicit permission.
            </p>
        </div>
    </div>
</body>
</html>
